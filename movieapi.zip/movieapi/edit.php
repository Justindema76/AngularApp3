<?php

require 'connect.php';
// Get the posted data.
$postdata = file_get_contents("php://input");

if(isset($postdata) && !empty($postdata))
{
  // Extract the data.
  $request = json_decode($postdata);

  // Validate the incoming data.
  if((int)$request->data->movieID < 1 || trim($request->data->movieName) === '' || trim($request->data->genre) === '' || trim($request->data->rating) === '' || trim($request->data->yearMade) === '' || trim($request->data->imageName) === '')
  {
    // If any required fields are missing or invalid, return a 400 status with an error message.
    http_response_code(400);
    echo json_encode(["message" => "Invalid movie data"]);
    exit;
  }

  // Sanitize the input data.
  $movieID = mysqli_real_escape_string($con, (int)$request->data->movieID);
  $movieName = mysqli_real_escape_string($con, trim($request->data->movieName));
  $genre = mysqli_real_escape_string($con, trim($request->data->genre));
  $rating = mysqli_real_escape_string($con, trim($request->data->rating));
  $yearMade = mysqli_real_escape_string($con, trim($request->data->yearMade));
  $imageName = mysqli_real_escape_string($con, trim($request->data->imageName));

  // Prepare the SQL UPDATE query to update the movie details.
  $sql = "UPDATE `movies` 
          SET `movieName` = '$movieName', `genre` = '$genre', `rating` = '$rating', `yearMade` = '$yearMade', `imageName` = '$imageName' 
          WHERE `movieID` = '{$movieID}' LIMIT 1";

  // Execute the query and check if the update was successful.
  if(mysqli_query($con, $sql))
  {
    // If successful, return a 204 status (No Content).
    http_response_code(204);
  }
  else
  {
    // If there was an error executing the query, return a 422 status (Unprocessable Entity).
    http_response_code(422);
  }

}
?>
