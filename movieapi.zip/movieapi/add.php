<?php
require 'connect.php';
 
// Get the posted data.
$postdata = file_get_contents("php://input");
 
if(isset($postdata) && !empty($postdata))
{
  // Extract the data.
  $request = json_decode($postdata);
  
 
  // Validate.
  if(trim($request->data->movieName) === '' || trim($request->data->genre) === '' ||
    trim($request->data->rating) === '' || trim($request->data->yearMade) === '')
  {
    return http_response_code(400);
  }
  
  // Sanitize.
  $movieName = mysqli_real_escape_string($con, trim($request->data->movieName));
  $genre = mysqli_real_escape_string($con, trim($request->data->genre));
  $rating = mysqli_real_escape_string($con, trim($request->data->rating));
  $yearMade = mysqli_real_escape_string($con, trim($request->data->yearMade));
 
 
  // Store.
  $sql = "INSERT INTO `movies`(`movieID`,`movieName`,`genre`, `rating`, `yearMade`) VALUES (null,'{$movieName}','{$genre}','{$rating}','{$yearMade}')";
 
  if(mysqli_query($con,$sql))
  {
    http_response_code(201);
    $movie = [
      'movieName' => $movieName,
      'genre' => $genre,
      'rating' => $rating,
      'yearMade' => $yearMade,
      'movieID'    => mysqli_insert_id($con)
    ];
    echo json_encode(['data'=>$movie]);
  }
  else
  {
    http_response_code(422);
  }
}
 
?>
 