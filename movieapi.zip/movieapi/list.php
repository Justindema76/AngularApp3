<?php

require 'connect.php';
    
$contacts = [];
$sql = "SELECT movieName, genre, rating, yearMade FROM movies";

if($result = mysqli_query($con,$sql))
{
  $count = 0;
  while($row = mysqli_fetch_assoc($result))
  {
    $movies[$count]['movieName'] = $row['movieName'];
    $movies[$count]['genre'] = $row['genre'];
    $movies[$count]['rating'] = $row['rating'];
    $movies[$count]['yearMade'] = $row['yearMade'];    
    $count++;
  }
    
  echo json_encode(['data'=>$movies]);
}
else
{
  http_response_code(404);
}
?>
