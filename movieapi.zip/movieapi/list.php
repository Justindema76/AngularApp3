<?php

require 'connect.php';
    
$movies = [];
$sql = "SELECT movieID, movieName, genre, rating, yearMade, imageName FROM movies";

if($result = mysqli_query($con,$sql))
{
  $count = 0;
  while($row = mysqli_fetch_assoc($result))
  {
    $movies[$count]['movieID'] = $row['movieID'];
    $movies[$count]['movieName'] = $row['movieName'];
    $movies[$count]['genre'] = $row['genre'];
    $movies[$count]['rating'] = $row['rating'];
    $movies[$count]['yearMade'] = $row['yearMade'];  
    $movies[$count]['imageName'] = $row['imageName'];    
    $count++;
  }
    
  echo json_encode(['data'=>$movies]);
}
else
{
  http_response_code(404);
}
?>
