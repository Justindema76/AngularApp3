<?php
require 'connect.php';

// Get the posted data.
$postdata = file_get_contents("php://input");
if (isset($postdata) && !empty($postdata)) {
  // Extract the data.
  $request = json_decode($postdata);
}

// Extract, validate and sanitize the id.
$movieID = ($_GET['movieID'] !== null && (int)$_GET['movieID'] > 0)? mysqli_real_escape_string($con, (int)$_GET['movieID']) : false;

if(!$movieID)
{
  return http_response_code(400);
}

// Delete.
$sql = "DELETE FROM `movies` WHERE `movieID` ='{$movieID}' LIMIT 1";

if(mysqli_query($con, $sql))
{
  http_response_code(204);
}
else
{
  return http_response_code(422);
}
